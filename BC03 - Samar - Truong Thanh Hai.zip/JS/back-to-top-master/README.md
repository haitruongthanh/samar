# Back to Top

A "Back to top" link to smoothly scroll back to the top of the page.

[Article on CodyHouse](https://codyhouse.co/gem/back-to-top)

[Demo](https://codyhouse.co/demo/back-to-top)
 
[License](https://codyhouse.co/license)

## Dependencies

This experiment is built upon the [CodyHouse Framework](https://github.com/CodyHouse/codyhouse-framework).

Make sure to include both the style.scss and util.js files of the framework.
